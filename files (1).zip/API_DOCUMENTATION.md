# SecureMoney API Documentation

## Base URL
```
Development: http://localhost:5000/api
Production: https://api.securemoney.in/api
```

## Authentication
Most endpoints require JWT authentication. Include the token in the Authorization header:
```
Authorization: Bearer <your_jwt_token>
```

---

## Authentication Endpoints

### 1. Request OTP
**Endpoint:** `POST /auth/request-otp`

**Description:** Initiates login/registration by sending OTP to mobile number

**Rate Limit:** 3 requests per 15 minutes per IP

**Request Body:**
```json
{
  "pan": "ABCDP1234F",
  "mobile": "9876543210",
  "walletAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
}
```

**Validations:**
- PAN: Must match format `[A-Z]{5}[0-9]{4}[A-Z]{1}`, 4th character must be 'P'
- Mobile: Must be 10 digits starting with 6-9
- Wallet: Must be valid Ethereum address (0x + 40 hex characters)

**Success Response (200):**
```json
{
  "success": true,
  "message": "OTP sent successfully",
  "expiresIn": 120
}
```

**Error Responses:**
- `400`: Invalid input data
- `429`: Too many requests (rate limit exceeded)
- `500`: Server error

**Notes:**
- OTP is valid for 2 minutes
- In development, OTP is logged to console
- In production, integrate with SMS gateway (Twilio, MSG91)

---

### 2. Verify OTP
**Endpoint:** `POST /auth/verify-otp`

**Description:** Verifies OTP and creates/logs in user

**Rate Limit:** 5 requests per 15 minutes per IP

**Request Body:**
```json
{
  "pan": "ABCDP1234F",
  "otp": "123456",
  "mobile": "9876543210",
  "walletAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "pan": "ABXXXX234F",
    "mobile": "9876543210",
    "walletAddress": "0x742d35cc6634c0532925a3b844bc9e7595f0beb",
    "userType": "borrower",
    "riskScore": 50
  }
}
```

**Error Responses:**
- `400`: Invalid OTP, OTP expired, or too many attempts
- `500`: Server error

**Notes:**
- JWT token expires in 7 days
- PAN is automatically masked in response
- Maximum 3 OTP verification attempts

---

## Loan Endpoints

### 3. Apply for Loan
**Endpoint:** `POST /loans/apply`

**Authentication:** Required

**Description:** Submit new loan application

**Request Body:**
```json
{
  "amount": 25000,
  "tenure": 6,
  "purpose": "Business expansion for my retail shop"
}
```

**Validations:**
- Amount: Between ₹1,000 and ₹1,00,000
- Tenure: Between 1 and 12 months
- Purpose: Required, string

**Success Response (201):**
```json
{
  "success": true,
  "message": "Loan application submitted successfully",
  "loan": {
    "loanId": "LN1707563421234",
    "amount": 25000,
    "tenure": 6,
    "interestRate": 15,
    "riskLevel": "medium",
    "totalRepayable": 27875,
    "emiAmount": 4646,
    "status": "pending"
  }
}
```

**Risk Scoring:**
- Low Risk (0-35 points): 12% interest
- Medium Risk (36-65 points): 15% interest
- High Risk (66-100 points): 18% interest

**Error Responses:**
- `400`: Invalid input or validation failed
- `401`: Authentication required
- `500`: Server error

---

### 4. Get My Loans
**Endpoint:** `GET /loans/my-loans`

**Authentication:** Required

**Description:** Fetch all loans for authenticated borrower

**Success Response (200):**
```json
{
  "success": true,
  "loans": [
    {
      "loanId": "LN1707563421234",
      "amount": 25000,
      "interestRate": 15,
      "tenure": 6,
      "purpose": "Business expansion",
      "status": "funded",
      "riskLevel": "medium",
      "totalRepayable": 27875,
      "emiAmount": 4646,
      "repaidAmount": 9292,
      "remainingAmount": 18583,
      "blockchainTxHash": "0x1234...",
      "lender": {
        "mobile": "9988776655",
        "walletAddress": "0x..."
      },
      "createdAt": "2024-02-10T10:30:21.000Z"
    }
  ]
}
```

---

### 5. Get Loan Details
**Endpoint:** `GET /loans/:loanId`

**Authentication:** Required

**Description:** Get detailed information about specific loan including repayment schedule

**Path Parameter:**
- `loanId`: Loan identifier (e.g., LN1707563421234)

**Success Response (200):**
```json
{
  "success": true,
  "loan": {
    "loanId": "LN1707563421234",
    "amount": 25000,
    "interestRate": 15,
    "tenure": 6,
    "totalRepayable": 27875,
    "emiAmount": 4646,
    "repaidAmount": 9292,
    "status": "active",
    "borrower": { ... },
    "lender": { ... }
  },
  "repayments": [
    {
      "emiNumber": 1,
      "amount": 4646,
      "dueDate": "2024-03-10T10:30:21.000Z",
      "paidDate": "2024-03-08T14:22:11.000Z",
      "status": "paid",
      "blockchainTxHash": "0x5678..."
    },
    {
      "emiNumber": 2,
      "amount": 4646,
      "dueDate": "2024-04-10T10:30:21.000Z",
      "status": "pending"
    }
  ]
}
```

**Error Responses:**
- `403`: Access denied (not borrower or lender)
- `404`: Loan not found

---

### 6. Get Pending Loans (Lenders)
**Endpoint:** `GET /loans/pending/all`

**Authentication:** Required

**Description:** Get all pending loans available for funding

**Success Response (200):**
```json
{
  "success": true,
  "loans": [
    {
      "loanId": "LN1707563421234",
      "amount": 25000,
      "interestRate": 15,
      "tenure": 6,
      "purpose": "Business expansion",
      "status": "pending",
      "riskLevel": "medium",
      "totalRepayable": 27875,
      "emiAmount": 4646,
      "expectedROI": 11.5,
      "borrower": {
        "mobile": "9876543210",
        "riskScore": 55,
        "totalLoans": 2,
        "defaultedLoans": 0
      },
      "createdAt": "2024-02-10T10:30:21.000Z"
    }
  ]
}
```

**Notes:**
- Limited to 50 most recent pending loans
- Sorted by creation date (newest first)

---

### 7. Fund Loan
**Endpoint:** `POST /loans/:loanId/fund`

**Authentication:** Required

**Description:** Fund a pending loan as a lender

**Path Parameter:**
- `loanId`: Loan identifier

**Request Body:**
```json
{
  "txHash": "0x1234567890abcdef..."
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Loan funded successfully",
  "loan": {
    "loanId": "LN1707563421234",
    "status": "funded",
    "lender": "507f1f77bcf86cd799439011",
    "blockchainTxHash": "0x1234...",
    "startDate": "2024-02-10T10:30:21.000Z",
    "endDate": "2024-08-10T10:30:21.000Z"
  }
}
```

**Error Responses:**
- `400`: Loan already funded or borrower cannot fund own loan
- `404`: Loan not found

**Notes:**
- Creates repayment schedule automatically
- Updates user type to 'both' (borrower + lender)
- Transfers funds to borrower immediately

---

### 8. Repay EMI
**Endpoint:** `POST /loans/:loanId/repay/:emiNumber`

**Authentication:** Required

**Description:** Make EMI payment for a loan

**Path Parameters:**
- `loanId`: Loan identifier
- `emiNumber`: EMI number (1-12)

**Request Body:**
```json
{
  "txHash": "0x9876543210fedcba..."
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "EMI paid successfully",
  "repayment": {
    "emiNumber": 3,
    "amount": 4646,
    "status": "paid",
    "paidDate": "2024-05-08T14:22:11.000Z",
    "blockchainTxHash": "0x9876..."
  }
}
```

**Error Responses:**
- `400`: EMI already paid
- `403`: Only borrower can repay
- `404`: Loan or repayment not found

**Notes:**
- Automatically completes loan when fully repaid
- Updates user statistics

---

## Rate Limits

| Endpoint | Limit | Window |
|----------|-------|--------|
| `/auth/request-otp` | 3 requests | 15 minutes |
| `/auth/verify-otp` | 5 requests | 15 minutes |
| All other API endpoints | 100 requests | 15 minutes |

---

## Error Response Format

All error responses follow this structure:
```json
{
  "success": false,
  "message": "Error description here"
}
```

**Common HTTP Status Codes:**
- `200`: Success
- `201`: Created
- `400`: Bad Request (validation error)
- `401`: Unauthorized (missing/invalid token)
- `403`: Forbidden (access denied)
- `404`: Not Found
- `429`: Too Many Requests (rate limit)
- `500`: Internal Server Error

---

## Testing with cURL

### Request OTP
```bash
curl -X POST http://localhost:5000/api/auth/request-otp \
  -H "Content-Type: application/json" \
  -d '{
    "pan": "ABCDP1234F",
    "mobile": "9876543210",
    "walletAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
  }'
```

### Verify OTP
```bash
curl -X POST http://localhost:5000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "pan": "ABCDP1234F",
    "otp": "123456",
    "mobile": "9876543210",
    "walletAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
  }'
```

### Apply for Loan
```bash
curl -X POST http://localhost:5000/api/loans/apply \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "amount": 25000,
    "tenure": 6,
    "purpose": "Business expansion"
  }'
```

---

## WebSocket Events (Future)

Planned real-time features:
- Loan funding notifications
- Repayment alerts
- Risk score updates
- Blockchain transaction confirmations

---

## Changelog

### v1.0.0 (Current)
- Initial API release
- Basic authentication with OTP
- Loan application and management
- Risk scoring algorithm
- Blockchain integration

### Planned v1.1.0
- SMS OTP integration
- Enhanced risk scoring with ML
- Loan modification endpoints
- Repayment history analytics
