# 🚀 SecureMoney - Quick Start Guide

Welcome! This guide will get you up and running in **5 minutes**.

---

## ⚡ Super Quick Start

### 1️⃣ **Extract the Project**
```bash
tar -xzf secure-money-complete.tar.gz
cd secure-money
```

### 2️⃣ **Auto Setup** (Recommended)
```bash
chmod +x setup.sh
./setup.sh
```

The script will:
- ✅ Check Node.js installation
- ✅ Install backend dependencies
- ✅ Create .env file
- ✅ Start MongoDB if not running

### 3️⃣ **Manual Configuration**
Edit `backend/.env` with your details:
```env
MONGODB_URI=mongodb://localhost:27017/securemoney
JWT_SECRET=change_this_to_a_random_string
```

### 4️⃣ **Start the Backend**
```bash
cd backend
npm run dev
```
✅ Backend running at: `http://localhost:5000`

### 5️⃣ **Start the Frontend** (New Terminal)
```bash
cd frontend
python3 -m http.server 8000
```
✅ Frontend running at: `http://localhost:8000`

### 6️⃣ **Test It Out!**
1. Open http://localhost:8000
2. Click "Apply Now"
3. Enter test data:
   - **PAN**: ABCDP1234F
   - **Mobile**: 9876543210
   - **Wallet**: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
4. Check console for OTP
5. Verify and start using!

---

## 📂 What's Included

### **Backend** (17 files)
- ✅ RESTful API with Express
- ✅ MongoDB integration
- ✅ JWT authentication
- ✅ OTP system (2-min expiry)
- ✅ Risk scoring algorithm
- ✅ Rate limiting
- ✅ Complete loan management

### **Frontend** (12 files)
- ✅ Landing page with animations
- ✅ Login + OTP verification
- ✅ Borrower dashboard
- ✅ Loan application form
- ✅ Lender dashboard
- ✅ Responsive design
- ✅ No framework dependencies

### **Blockchain** (2 files)
- ✅ Solidity smart contract
- ✅ Deployment scripts
- ✅ Interaction utilities

### **Documentation** (4 files)
- ✅ Comprehensive README
- ✅ API Documentation
- ✅ Deployment Guide
- ✅ Project Summary

---

## 🎯 Key Features

| Feature | Status | Description |
|---------|--------|-------------|
| **PAN Authentication** | ✅ | Instant KYC with PAN + OTP |
| **Risk Scoring** | ✅ | AI-powered 100-point system |
| **Loan Management** | ✅ | ₹1K-₹1L, 1-12 months |
| **Blockchain** | ✅ | Smart contracts ready |
| **Security** | ✅ | Rate limiting, JWT, encryption |
| **Responsive** | ✅ | Mobile + desktop |

---

## 🧪 Testing

### Test User Flow
1. **Register**
   - PAN: ABCDP1234F
   - Mobile: 9876543210
   - Check console for OTP

2. **Apply for Loan**
   - Amount: ₹25,000
   - Tenure: 6 months
   - Purpose: Business expansion

3. **View Dashboard**
   - See your loans
   - Check repayment schedule

4. **Become Lender**
   - Browse available loans
   - Fund loans to earn returns

### API Testing
```bash
# Health check
curl http://localhost:5000/health

# Request OTP
curl -X POST http://localhost:5000/api/auth/request-otp \
  -H "Content-Type: application/json" \
  -d '{"pan":"ABCDP1234F","mobile":"9876543210","walletAddress":"0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"}'
```

---

## 🛠️ Troubleshooting

### MongoDB Not Starting?
```bash
# Check status
sudo systemctl status mongod

# Start it
sudo systemctl start mongod

# Or use Docker
docker run -d -p 27017:27017 mongo:latest
```

### Port Already in Use?
```bash
# Change backend port in .env
PORT=5001

# Change frontend port
python3 -m http.server 8001
```

### Dependencies Error?
```bash
cd backend
rm -rf node_modules package-lock.json
npm install
```

---

## 📚 Documentation

| Document | Purpose |
|----------|---------|
| **README.md** | Complete project overview |
| **API_DOCUMENTATION.md** | All API endpoints |
| **DEPLOYMENT_GUIDE.md** | Production deployment |
| **PROJECT_SUMMARY.md** | Quick reference |

---

## 🚀 Next Steps

### For Development
1. ✅ Test all features locally
2. ✅ Customize branding/colors
3. ✅ Add more features
4. ✅ Integrate real SMS API

### For Production
1. ✅ Deploy smart contract to testnet
2. ✅ Setup MongoDB Atlas
3. ✅ Configure SSL/HTTPS
4. ✅ Deploy to cloud server
5. ✅ Setup monitoring

**See DEPLOYMENT_GUIDE.md for detailed instructions**

---

## 🎨 Customization

### Change Colors
Edit CSS variables in:
- `frontend/css/landing.css`
- `frontend/css/login.css`
- `frontend/css/dashboard.css`

```css
:root {
    --primary: #00D084;      /* Main green */
    --accent: #FF6B35;       /* Orange accent */
    --dark: #0F172A;         /* Background */
}
```

### Add Logo
Replace text logo with image in:
- `frontend/index.html`
- `frontend/login.html`
- `frontend/dashboard.html`

---

## 🔐 Security Notes

### Development
- ✅ OTP logged to console
- ✅ Mock blockchain transactions
- ✅ Relaxed rate limits

### Production
- ⚠️ Change JWT_SECRET
- ⚠️ Enable real SMS OTP
- ⚠️ Deploy smart contracts
- ⚠️ Use HTTPS everywhere
- ⚠️ Tighten rate limits

---

## 💡 Pro Tips

1. **Use PM2** for backend in production
2. **Setup MongoDB Atlas** for cloud database
3. **Enable HTTPS** with Let's Encrypt (free)
4. **Monitor logs** with PM2 or Winston
5. **Backup database** regularly

---

## 📞 Need Help?

- 📖 Check API_DOCUMENTATION.md
- 🚀 Read DEPLOYMENT_GUIDE.md
- 💻 Review code comments
- 🔍 Search error messages

---

## ✅ Checklist

**Before Deploying:**
- [ ] All tests pass
- [ ] .env configured
- [ ] MongoDB running
- [ ] Smart contract deployed
- [ ] SSL certificates ready
- [ ] Backups configured
- [ ] Monitoring setup

---

## 🎉 You're Ready!

Your SecureMoney platform is now ready to use. Start building the future of microfinance! 🚀

**Happy Coding! 💚**
